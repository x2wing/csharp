﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.progressBarTempirature = new System.Windows.Forms.ProgressBar();
            this.labelTempirature = new System.Windows.Forms.Label();
            this.textBoxCacacola = new System.Windows.Forms.TextBox();
            this.textBoxPepsi = new System.Windows.Forms.TextBox();
            this.textBoxSprite = new System.Windows.Forms.TextBox();
            this.textBoxFanta = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Запасы = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelCostFanta = new System.Windows.Forms.Label();
            this.labelCostSprite = new System.Windows.Forms.Label();
            this.labelCostPepsi = new System.Windows.Forms.Label();
            this.labelCostCocacola = new System.Windows.Forms.Label();
            this.buttonBuyFanta = new System.Windows.Forms.Button();
            this.buttonBuySprite = new System.Windows.Forms.Button();
            this.buttonBuyPepsi = new System.Windows.Forms.Button();
            this.buttonBuyCocacola = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button9 = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonTakeChange = new System.Windows.Forms.Button();
            this.buttonTakeDrink = new System.Windows.Forms.Button();
            this.richTextBoxTerm = new System.Windows.Forms.RichTextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.button10rm = new System.Windows.Forms.Button();
            this.button5r = new System.Windows.Forms.Button();
            this.button2r = new System.Windows.Forms.Button();
            this.button1r = new System.Windows.Forms.Button();
            this.button500r = new System.Windows.Forms.Button();
            this.button100r = new System.Windows.Forms.Button();
            this.button50r = new System.Windows.Forms.Button();
            this.button10r = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.watch = new System.Windows.Forms.Timer(this.components);
            this.labelTime = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.btnBrokenCoin = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.Запасы.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // progressBarTempirature
            // 
            this.progressBarTempirature.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.progressBarTempirature.Location = new System.Drawing.Point(13, 38);
            this.progressBarTempirature.Name = "progressBarTempirature";
            this.progressBarTempirature.Size = new System.Drawing.Size(171, 18);
            this.progressBarTempirature.TabIndex = 0;
            this.progressBarTempirature.Value = 50;
            // 
            // labelTempirature
            // 
            this.labelTempirature.AutoSize = true;
            this.labelTempirature.Location = new System.Drawing.Point(92, 78);
            this.labelTempirature.Name = "labelTempirature";
            this.labelTempirature.Size = new System.Drawing.Size(13, 13);
            this.labelTempirature.TabIndex = 1;
            this.labelTempirature.Text = "0";
            // 
            // textBoxCacacola
            // 
            this.textBoxCacacola.Location = new System.Drawing.Point(105, 17);
            this.textBoxCacacola.Name = "textBoxCacacola";
            this.textBoxCacacola.Size = new System.Drawing.Size(49, 20);
            this.textBoxCacacola.TabIndex = 3;
            this.textBoxCacacola.Text = "8";
            // 
            // textBoxPepsi
            // 
            this.textBoxPepsi.Location = new System.Drawing.Point(105, 43);
            this.textBoxPepsi.Name = "textBoxPepsi";
            this.textBoxPepsi.Size = new System.Drawing.Size(49, 20);
            this.textBoxPepsi.TabIndex = 4;
            this.textBoxPepsi.Text = "10";
            // 
            // textBoxSprite
            // 
            this.textBoxSprite.Location = new System.Drawing.Point(105, 69);
            this.textBoxSprite.Name = "textBoxSprite";
            this.textBoxSprite.Size = new System.Drawing.Size(49, 20);
            this.textBoxSprite.TabIndex = 5;
            this.textBoxSprite.Text = "6";
            // 
            // textBoxFanta
            // 
            this.textBoxFanta.Location = new System.Drawing.Point(105, 95);
            this.textBoxFanta.Name = "textBoxFanta";
            this.textBoxFanta.Size = new System.Drawing.Size(49, 20);
            this.textBoxFanta.TabIndex = 6;
            this.textBoxFanta.Text = "5";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Coca-cola";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Pepsi";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(65, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Sprite";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(65, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Fanta";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(58, 153);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(96, 34);
            this.button1.TabIndex = 11;
            this.button1.Text = "Пополнить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.progressBarTempirature);
            this.groupBox1.Controls.Add(this.labelTempirature);
            this.groupBox1.Location = new System.Drawing.Point(-1, -2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(202, 208);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Датчик темпиратуры";
            // 
            // Запасы
            // 
            this.Запасы.Controls.Add(this.label1);
            this.Запасы.Controls.Add(this.button1);
            this.Запасы.Controls.Add(this.textBoxCacacola);
            this.Запасы.Controls.Add(this.label4);
            this.Запасы.Controls.Add(this.textBoxPepsi);
            this.Запасы.Controls.Add(this.label3);
            this.Запасы.Controls.Add(this.textBoxSprite);
            this.Запасы.Controls.Add(this.label2);
            this.Запасы.Controls.Add(this.textBoxFanta);
            this.Запасы.Location = new System.Drawing.Point(1, 205);
            this.Запасы.Name = "Запасы";
            this.Запасы.Size = new System.Drawing.Size(200, 211);
            this.Запасы.TabIndex = 13;
            this.Запасы.TabStop = false;
            this.Запасы.Text = "Запасы";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pictureBox4);
            this.groupBox2.Controls.Add(this.pictureBox3);
            this.groupBox2.Controls.Add(this.pictureBox2);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.labelCostFanta);
            this.groupBox2.Controls.Add(this.labelCostSprite);
            this.groupBox2.Controls.Add(this.labelCostPepsi);
            this.groupBox2.Controls.Add(this.labelCostCocacola);
            this.groupBox2.Controls.Add(this.buttonBuyFanta);
            this.groupBox2.Controls.Add(this.buttonBuySprite);
            this.groupBox2.Controls.Add(this.buttonBuyPepsi);
            this.groupBox2.Controls.Add(this.buttonBuyCocacola);
            this.groupBox2.Location = new System.Drawing.Point(207, -2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(243, 418);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Напитки";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::WindowsFormsApplication1.Properties.Resources.fanta1;
            this.pictureBox4.ImageLocation = "";
            this.pictureBox4.Location = new System.Drawing.Point(31, 274);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(70, 70);
            this.pictureBox4.TabIndex = 15;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::WindowsFormsApplication1.Properties.Resources.sprite;
            this.pictureBox3.ImageLocation = "";
            this.pictureBox3.Location = new System.Drawing.Point(31, 193);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(70, 70);
            this.pictureBox3.TabIndex = 14;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::WindowsFormsApplication1.Properties.Resources.pepsi;
            this.pictureBox2.ImageLocation = "";
            this.pictureBox2.Location = new System.Drawing.Point(31, 112);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(70, 70);
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApplication1.Properties.Resources.cocacola;
            this.pictureBox1.ImageLocation = "";
            this.pictureBox1.Location = new System.Drawing.Point(31, 31);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(70, 70);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // labelCostFanta
            // 
            this.labelCostFanta.AutoSize = true;
            this.labelCostFanta.Location = new System.Drawing.Point(195, 305);
            this.labelCostFanta.Name = "labelCostFanta";
            this.labelCostFanta.Size = new System.Drawing.Size(31, 13);
            this.labelCostFanta.TabIndex = 11;
            this.labelCostFanta.Text = "42 р.";
            // 
            // labelCostSprite
            // 
            this.labelCostSprite.AutoSize = true;
            this.labelCostSprite.Location = new System.Drawing.Point(195, 227);
            this.labelCostSprite.Name = "labelCostSprite";
            this.labelCostSprite.Size = new System.Drawing.Size(31, 13);
            this.labelCostSprite.TabIndex = 10;
            this.labelCostSprite.Text = "48 р.";
            this.labelCostSprite.Click += new System.EventHandler(this.label7_Click);
            // 
            // labelCostPepsi
            // 
            this.labelCostPepsi.AutoSize = true;
            this.labelCostPepsi.Location = new System.Drawing.Point(195, 143);
            this.labelCostPepsi.Name = "labelCostPepsi";
            this.labelCostPepsi.Size = new System.Drawing.Size(31, 13);
            this.labelCostPepsi.TabIndex = 9;
            this.labelCostPepsi.Text = "45 р.";
            // 
            // labelCostCocacola
            // 
            this.labelCostCocacola.AutoSize = true;
            this.labelCostCocacola.Location = new System.Drawing.Point(195, 59);
            this.labelCostCocacola.Name = "labelCostCocacola";
            this.labelCostCocacola.Size = new System.Drawing.Size(31, 13);
            this.labelCostCocacola.TabIndex = 8;
            this.labelCostCocacola.Text = "50 р.";
            // 
            // buttonBuyFanta
            // 
            this.buttonBuyFanta.Location = new System.Drawing.Point(107, 274);
            this.buttonBuyFanta.Name = "buttonBuyFanta";
            this.buttonBuyFanta.Size = new System.Drawing.Size(70, 70);
            this.buttonBuyFanta.TabIndex = 6;
            this.buttonBuyFanta.Text = "Купить";
            this.buttonBuyFanta.UseVisualStyleBackColor = true;
            this.buttonBuyFanta.Click += new System.EventHandler(this.buttonBuyFanta_Click);
            // 
            // buttonBuySprite
            // 
            this.buttonBuySprite.Location = new System.Drawing.Point(107, 193);
            this.buttonBuySprite.Name = "buttonBuySprite";
            this.buttonBuySprite.Size = new System.Drawing.Size(70, 70);
            this.buttonBuySprite.TabIndex = 5;
            this.buttonBuySprite.Text = "Купить";
            this.buttonBuySprite.UseVisualStyleBackColor = true;
            this.buttonBuySprite.Click += new System.EventHandler(this.buttonBuySprite_Click);
            // 
            // buttonBuyPepsi
            // 
            this.buttonBuyPepsi.Location = new System.Drawing.Point(107, 112);
            this.buttonBuyPepsi.Name = "buttonBuyPepsi";
            this.buttonBuyPepsi.Size = new System.Drawing.Size(70, 70);
            this.buttonBuyPepsi.TabIndex = 4;
            this.buttonBuyPepsi.Text = "Купить";
            this.buttonBuyPepsi.UseVisualStyleBackColor = true;
            this.buttonBuyPepsi.Click += new System.EventHandler(this.buttonBuyPepsi_Click);
            // 
            // buttonBuyCocacola
            // 
            this.buttonBuyCocacola.Location = new System.Drawing.Point(107, 31);
            this.buttonBuyCocacola.Name = "buttonBuyCocacola";
            this.buttonBuyCocacola.Size = new System.Drawing.Size(70, 70);
            this.buttonBuyCocacola.TabIndex = 3;
            this.buttonBuyCocacola.Text = "Купить";
            this.buttonBuyCocacola.UseVisualStyleBackColor = true;
            this.buttonBuyCocacola.Click += new System.EventHandler(this.buttonBuyCocacola_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button9);
            this.groupBox4.Controls.Add(this.buttonCancel);
            this.groupBox4.Controls.Add(this.buttonTakeChange);
            this.groupBox4.Controls.Add(this.buttonTakeDrink);
            this.groupBox4.Location = new System.Drawing.Point(452, -2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(329, 168);
            this.groupBox4.TabIndex = 15;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Меню пользователя";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(217, 90);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(67, 53);
            this.button9.TabIndex = 19;
            this.button9.Text = "Вызов техника";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(217, 38);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(67, 53);
            this.buttonCancel.TabIndex = 18;
            this.buttonCancel.Text = "Отмена";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonTakeChange
            // 
            this.buttonTakeChange.Location = new System.Drawing.Point(85, 90);
            this.buttonTakeChange.Name = "buttonTakeChange";
            this.buttonTakeChange.Size = new System.Drawing.Size(67, 53);
            this.buttonTakeChange.TabIndex = 17;
            this.buttonTakeChange.Text = "Забрать сдачу";
            this.buttonTakeChange.UseVisualStyleBackColor = true;
            this.buttonTakeChange.Click += new System.EventHandler(this.buttonTakeChange_Click);
            // 
            // buttonTakeDrink
            // 
            this.buttonTakeDrink.Location = new System.Drawing.Point(85, 38);
            this.buttonTakeDrink.Name = "buttonTakeDrink";
            this.buttonTakeDrink.Size = new System.Drawing.Size(67, 53);
            this.buttonTakeDrink.TabIndex = 16;
            this.buttonTakeDrink.Text = "Забрать напиток";
            this.buttonTakeDrink.UseVisualStyleBackColor = true;
            this.buttonTakeDrink.Click += new System.EventHandler(this.buttonTakeDrink_Click);
            // 
            // richTextBoxTerm
            // 
            this.richTextBoxTerm.Location = new System.Drawing.Point(452, 168);
            this.richTextBoxTerm.Name = "richTextBoxTerm";
            this.richTextBoxTerm.ReadOnly = true;
            this.richTextBoxTerm.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.richTextBoxTerm.Size = new System.Drawing.Size(329, 74);
            this.richTextBoxTerm.TabIndex = 16;
            this.richTextBoxTerm.Text = "";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnBrokenCoin);
            this.groupBox5.Controls.Add(this.button2);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.button10rm);
            this.groupBox5.Controls.Add(this.button5r);
            this.groupBox5.Controls.Add(this.button2r);
            this.groupBox5.Controls.Add(this.button1r);
            this.groupBox5.Controls.Add(this.button500r);
            this.groupBox5.Controls.Add(this.button100r);
            this.groupBox5.Controls.Add(this.button50r);
            this.groupBox5.Controls.Add(this.button10r);
            this.groupBox5.Location = new System.Drawing.Point(452, 245);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(329, 171);
            this.groupBox5.TabIndex = 17;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Купюроприемник";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(214, 142);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 13);
            this.label10.TabIndex = 28;
            this.label10.Text = "Монеты";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(58, 142);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "Купюры";
            // 
            // button10rm
            // 
            this.button10rm.Location = new System.Drawing.Point(240, 57);
            this.button10rm.Name = "button10rm";
            this.button10rm.Size = new System.Drawing.Size(41, 34);
            this.button10rm.TabIndex = 27;
            this.button10rm.Text = "10";
            this.button10rm.UseVisualStyleBackColor = true;
            this.button10rm.Click += new System.EventHandler(this.button10rm_Click);
            // 
            // button5r
            // 
            this.button5r.Location = new System.Drawing.Point(240, 14);
            this.button5r.Name = "button5r";
            this.button5r.Size = new System.Drawing.Size(41, 34);
            this.button5r.TabIndex = 26;
            this.button5r.Text = "5";
            this.button5r.UseVisualStyleBackColor = true;
            this.button5r.Click += new System.EventHandler(this.button5r_Click);
            // 
            // button2r
            // 
            this.button2r.Location = new System.Drawing.Point(191, 57);
            this.button2r.Name = "button2r";
            this.button2r.Size = new System.Drawing.Size(41, 34);
            this.button2r.TabIndex = 25;
            this.button2r.Text = "2";
            this.button2r.UseVisualStyleBackColor = true;
            this.button2r.Click += new System.EventHandler(this.button2r_Click);
            // 
            // button1r
            // 
            this.button1r.Location = new System.Drawing.Point(191, 14);
            this.button1r.Name = "button1r";
            this.button1r.Size = new System.Drawing.Size(41, 34);
            this.button1r.TabIndex = 24;
            this.button1r.Text = "1";
            this.button1r.UseVisualStyleBackColor = true;
            this.button1r.Click += new System.EventHandler(this.button1r_Click);
            // 
            // button500r
            // 
            this.button500r.Location = new System.Drawing.Point(85, 57);
            this.button500r.Name = "button500r";
            this.button500r.Size = new System.Drawing.Size(41, 34);
            this.button500r.TabIndex = 23;
            this.button500r.Text = "500";
            this.button500r.UseVisualStyleBackColor = true;
            this.button500r.Click += new System.EventHandler(this.button500r_Click);
            // 
            // button100r
            // 
            this.button100r.Location = new System.Drawing.Point(85, 14);
            this.button100r.Name = "button100r";
            this.button100r.Size = new System.Drawing.Size(41, 34);
            this.button100r.TabIndex = 22;
            this.button100r.Text = "100";
            this.button100r.UseVisualStyleBackColor = true;
            this.button100r.Click += new System.EventHandler(this.button100r_Click);
            // 
            // button50r
            // 
            this.button50r.Location = new System.Drawing.Point(36, 57);
            this.button50r.Name = "button50r";
            this.button50r.Size = new System.Drawing.Size(41, 34);
            this.button50r.TabIndex = 21;
            this.button50r.Text = "50";
            this.button50r.UseVisualStyleBackColor = true;
            this.button50r.Click += new System.EventHandler(this.button50r_Click);
            // 
            // button10r
            // 
            this.button10r.Location = new System.Drawing.Point(36, 14);
            this.button10r.Name = "button10r";
            this.button10r.Size = new System.Drawing.Size(41, 34);
            this.button10r.TabIndex = 20;
            this.button10r.Text = "10";
            this.button10r.UseVisualStyleBackColor = true;
            this.button10r.Click += new System.EventHandler(this.button10r_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 10000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // watch
            // 
            this.watch.Enabled = true;
            this.watch.Interval = 1000;
            this.watch.Tick += new System.EventHandler(this.watch_Tick);
            // 
            // labelTime
            // 
            this.labelTime.AutoSize = true;
            this.labelTime.Location = new System.Drawing.Point(266, 427);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(51, 13);
            this.labelTime.TabIndex = 18;
            this.labelTime.Text = "0 секунд";
            this.labelTime.Click += new System.EventHandler(this.label5_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(129, 426);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "Время работы автомата:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(36, 97);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(90, 34);
            this.button2.TabIndex = 29;
            this.button2.Text = "Подделльная купюра";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnBrokenCoin
            // 
            this.btnBrokenCoin.Location = new System.Drawing.Point(191, 97);
            this.btnBrokenCoin.Name = "btnBrokenCoin";
            this.btnBrokenCoin.Size = new System.Drawing.Size(90, 34);
            this.btnBrokenCoin.TabIndex = 30;
            this.btnBrokenCoin.Text = "Поддельная монета";
            this.btnBrokenCoin.UseVisualStyleBackColor = true;
            this.btnBrokenCoin.Click += new System.EventHandler(this.btnBrokenCoin_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(786, 460);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labelTime);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.richTextBoxTerm);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Запасы);
            this.Name = "Form1";
            this.Text = "Запасы";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Запасы.ResumeLayout(false);
            this.Запасы.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ProgressBar progressBarTempirature;
        private System.Windows.Forms.Label labelTempirature;
        private System.Windows.Forms.TextBox textBoxCacacola;
        private System.Windows.Forms.TextBox textBoxPepsi;
        private System.Windows.Forms.TextBox textBoxSprite;
        private System.Windows.Forms.TextBox textBoxFanta;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox Запасы;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label labelCostFanta;
        private System.Windows.Forms.Label labelCostSprite;
        private System.Windows.Forms.Label labelCostPepsi;
        private System.Windows.Forms.Label labelCostCocacola;
        private System.Windows.Forms.Button buttonBuyFanta;
        private System.Windows.Forms.Button buttonBuySprite;
        private System.Windows.Forms.Button buttonBuyPepsi;
        private System.Windows.Forms.Button buttonBuyCocacola;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Button buttonTakeChange;
        private System.Windows.Forms.Button buttonTakeDrink;
        private System.Windows.Forms.RichTextBox richTextBoxTerm;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button10rm;
        private System.Windows.Forms.Button button5r;
        private System.Windows.Forms.Button button2r;
        private System.Windows.Forms.Button button1r;
        private System.Windows.Forms.Button button500r;
        private System.Windows.Forms.Button button100r;
        private System.Windows.Forms.Button button50r;
        private System.Windows.Forms.Button button10r;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Timer watch;
        private System.Windows.Forms.Label labelTime;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnBrokenCoin;
        private System.Windows.Forms.Button button2;
    }
}

